import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-layout-service',
  templateUrl: './layout-service.component.html',
  styleUrls: ['./layout-service.component.scss']
})
export class LayoutServiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {}

}
