import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'chips-example-1',
  templateUrl: './chips-example-1.component.html',
  styleUrls: ['./chips-example-1.component.scss']
})
export class ChipsExample1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
