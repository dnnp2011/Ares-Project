import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'grid-list-example-1',
  templateUrl: './grid-list-example-1.component.html',
  styleUrls: ['./grid-list-example-1.component.scss']
})
export class GridListExample1Component implements OnInit {
  constructor() {}

  ngOnInit(): void {
  }

}
