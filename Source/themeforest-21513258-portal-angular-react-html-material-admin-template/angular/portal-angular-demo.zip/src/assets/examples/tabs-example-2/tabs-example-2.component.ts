import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tabs-example-2',
  templateUrl: './tabs-example-2.component.html',
  styleUrls: ['./tabs-example-2.component.scss']
})
export class TabsExample2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
