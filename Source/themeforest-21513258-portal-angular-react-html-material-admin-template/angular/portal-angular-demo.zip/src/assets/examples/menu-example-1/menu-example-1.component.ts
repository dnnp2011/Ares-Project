import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'menu-example-1',
  templateUrl: './menu-example-1.component.html',
  styleUrls: ['./menu-example-1.component.scss']
})
export class MenuExample1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
