import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'button-example-1',
  templateUrl: './button-example-1.component.html',
  styleUrls: ['./button-example-1.component.scss']
})
export class ButtonExample1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
