import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'colors-example',
  templateUrl: './colors.component.html',
  styleUrls: ['./colors.component.scss']
})
export class ColorsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
