const styles = theme => ({
  'comment-icon--selected': {
    color: theme.palette.primary.main
  }
});

export default styles;
