const styles = theme => ({
  cardHeader: {
    backgroundColor: theme.palette.background.default
  },
  cardTitle: {
    fontSize: '1em',
  }
});

export default styles;
