/**
 *  This file contains the variables used in other gulp files
 *  which defines tasks
 *  By design, we only put there very generic config values
 *  which are used in several places to keep good readability
 *  of the tasks
 */

const argv = require('yargs').argv;

let base = '/';
let dist = 'dist';
if(argv.prod) {
  base = '/html/';
  dist = '../dist/html';
} else if(argv.dev) {
  base = '/portal/html/';
  dist = '../dist/html';
}

/**
 *  The main paths of your project handle these with care
 */

exports.strings = [
];

exports.target = {
  src: 'src',
  dist: dist
};

exports.paths = {
  src: exports.target.src,
  dist: exports.target.dist
};

exports.data = {
  base: base
};

exports.layouts = [
  {
    layout: 'classic',
    outputFolder: '',
  },
  {
    layout: 'toolbar',
    outputFolder: 'toolbar',
  },
  {
    layout: 'compact',
    outputFolder: 'compact',
  },
  {
    layout: 'boxed',
    outputFolder: 'boxed',
  },
  {
    layout: 'tabbed',
    outputFolder: 'tabbed',
  },
  {
    layout: 'funky',
    outputFolder: 'funky',
  }
];

exports.separator = '-';
