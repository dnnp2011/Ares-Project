<a name="1.5.0"></a>
# 1.5.0 (May 22, 2018)

* **no-changes:** no changes to the HTML in this version

<a name="1.4.0"></a>
# 1.4.0 (May 2, 2018)


### Features


* **dashboard:** added project dashboard
* **dashboard:** added issues status widget
* **dashboard:** added tasks by user widget
* **dashboard:** added weekly issues widget
* **dashboards:** added new dashboard widget, the project stepper


<a name="1.3.0"></a>
# 1.3.0 (April 17, 2018)


### Features


* **dashboards:** added new cryptocurrency dashboard
* **crypto:** added marquee3000 cryptocurrency ticker
* **crypto:** added cryptocurrency table widget
* **crypto:** added cryptocurrency chart widget


<a name="1.2.0"></a>
# 1.2.0 (April 3, 2018)


### Bug Fixes


* **toolbar:** aligned icons

### Features


* **dashboard:** added e-commerce dashbord


<a name="1.1.0"></a>
# 1.1.0 (March 21, 2018)


### Bug Fixes


* **chartjs:** make sure chartjs loads from node_modules
* **charts:** fix for chart colors on IE11
* **charts:** hover background color for doughnut chart set to secondary
* **IE11:** colors are now using mixins and CSS variables to make it compatible with IE11
* **IE11:** notification sidenav fix for IE11
* **layouts:** fix issue with layouts menu and snackbars appearance
* **menus:** prevents default functionality for links on menus that open/close dropdowns and sidemenus
* **pages:** all pages on menus show as active when visited
* **sidenav:** menu dropdown stays open on page load if we are on one of the subpages
* **themes:** dark themes now utilise proper colors on boxed & tabbed layouts background
* **themes:** data tables now uses theme colors
* **themes:** switcher now uses nicer js code to change CSS link
* **toolbar:** colors of toolbar icons were wrong after MDC update

### Features


* **apps:** add chat app
* **apps:** Added contacts app
* **apps:** added notes app
* **apps:** fix scrollbars in chat app
* **layouts:** added new Boxed layout
* **layouts:** added new Tabbed layout
* **Layouts:** added funky layout
* **loader:** added pace and styled loader
* **MDC:** updated Material Design Components to v0.32.0
* **themes:** themes now persist when reloading page


<a name="1.0.0"></a>
# 1.0.0 (March 1, 2018)


### Bug Fixes

* **chartjs:** fixed missing import for toolbar layout
* **chartjs:** fixed bug where chart.js was missing from compact layout
* **dashboard:** add transition to widget cards
* **dashboard:** changed doughnut devices color
* **email:** fix for path of images on email app
* **layouts:** added missing imports. close sidenav button fix compact menu
* **layouts:** fixed themeing colors & menu items compact menu
* **layouts:** use base in switcher urls
* **layouts:** fixed paths(absolute) for switching layouts
* **layouts:** use base tag for layout paths
* **menus:** properly hide/show menu burger icon for each layout
* **menus:** fixed menus to work with new mdc version
* **misc:** fixed css for dark navigation
* **misc:** fixed markup/classes on email, notification, todo for the new update
* **misc:** fixed notification card classes
* **pages:** broken markup
* **pages:** validation errors
* **paths:** fixed paths to assets that work for all layouts
* **rtl:** fixed tabs when switching to rtl
* **rtl:** menu and notification sidebar fixes
* **sidenav:** fixed nested list background color for light themes
* **sidenav:** removed shadow when closed
* **sidenav:** fixed selected list items on light theme
* **theming:** broken markup
* **todo:** fixed shitty todo zindex
* **validation:** validated pages


### Features

* **cards:** added styling for new mdc
* **cards:** fixed cards for new mdc
* **colors:** added colors page
* **layouts:** added menu items for compact menu
* **dashboard:** dashboard layout uses mdc grid layout
* **docs:** added basic docs.
* **email:** added an extra email card
* **email:** populated email app contacts
* **email:** first email app attempt
* **logo:** added logo to the pages
* **menu:** expansion menu icon now toggles on click
* **menu:** items organized to dropdowns
* **rtl:** changed rtl switch button
* **rtl:** added rtl switch to the toolbar
* **styling:** various fixes
* **themes:** added switcher and 2 themes
* **themes:** added all themes por-311
* **todo:** basic todo app
* **todo:** style the fuck out of it
* **toolbar:** added toolbar menu
* **toolbar:** more menu items
* **typography:** added typography page


